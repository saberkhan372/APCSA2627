# Materials

- W02: Make numeric types visible — included in W02/
- L02: Two Meanings of Plus — provided by your teacher in Classroom; not included in this public packet
- L03: Area and Circumference of a Circle — provided by your teacher in Classroom; not included in this public packet
- L04: Painting a Room — provided by your teacher in Classroom; not included in this public packet