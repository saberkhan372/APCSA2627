# ExpressionLab and Circle

Friday, September 11, 2026, 13:00-14:15

## In class
Repair average, wholePart and remainder in ExpressionLab. Use Circle as a short transfer on constants, assignment and numeric output. Read one keyboard value with Scanner.

## Turn in
ExpressionLab checks; value/type table; explain why double x = 7/2 loses the fraction.

## After class
20 min: L04 Painting a Room calculation and two expected outputs; finish any ExpressionLab repair.

Due: 2026-09-15
