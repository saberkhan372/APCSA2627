# Array algorithms and reversal checkpoint

Wednesday, December 16, 2026, 09:30-10:45

## In class
Finish the array toolkit, then reverse actual elements in place. Test empty, one-element, odd and even lengths. Explain copying versus aliasing.

## Turn in
Array algorithm checks; reverse method; four test cases.

## After class
None over winter break. Save the array summary and expected outputs for Jan 6.
