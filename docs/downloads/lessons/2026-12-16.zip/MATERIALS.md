# Materials

- W41: Build the array algorithm toolkit — included in W41/
- L17: Reversing an Array — provided by your teacher in Classroom; not included in this public packet
- W42: Shift without overwriting — included in W42/