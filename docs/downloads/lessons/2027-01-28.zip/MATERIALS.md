# Materials

- L18: Shopping Cart using an ArrayList — provided by your teacher in Classroom; not included in this public packet
- W49: Use the five ArrayList methods — included in W49/
- W50: Traverse a changing-size collection — included in W50/