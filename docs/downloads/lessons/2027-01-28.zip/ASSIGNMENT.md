# Shopping Cart: build

Thursday, January 28, 2027, 08:50-10:05

## In class
Create ArrayList<Item>, instantiate Item objects and compute quantity-weighted totals. Start with three fixed products; add interactive input only after the core works.

## Turn in
Typed cart with correct total and getPrice/getQuantity calls; fixed test basket.

## After class
20 min: finish one receipt test, including quantity greater than one.

Due: 2027-02-01
