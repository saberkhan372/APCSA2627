# FRQ 4: independent 2D transfer

Friday, April 16, 2027, 13:00-14:15

## In class
Attempt 2024 Q4 GridPath part (a) (23 min) and trace part (b). Correct bounds and helper-method calls. If absent for senior retreat, use Apr 22.

## Turn in
Timed 2D method and corrected row/column trace.

## After class
15 min: revise the two most common 2D errors.

Due: 2027-04-20
