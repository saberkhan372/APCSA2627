# FRQ simulation: first pair

Friday, April 30, 2027, 10:15-11:30

## In class
Use a fresh current-format Methods/Control and Class Design pair for 50 minutes, then debrief for 25 minutes.

## Turn in
Two independent FRQs and focused correction notes.

## After class
20 min: finish one correction; keep the remaining pair unseen.

Due: 2027-05-04
