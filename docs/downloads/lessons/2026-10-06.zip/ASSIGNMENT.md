# Date Validation and Boolean equivalence

Tuesday, October 6, 2026, 13:00-14:15

## In class
Implement the date checks. Build a truth table for a compound condition, negate it with De Morgan and compare both versions; use short-circuit guards.

## Turn in
Validated program; leap-year/boundary tests; equivalent-condition proof.

## After class
20 min: finish Date Validation tests and repair one compound Boolean expression.

Due: 2026-10-08
