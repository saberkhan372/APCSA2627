# Materials

- L08: Date Validation — provided by your teacher in Classroom; not included in this public packet
- W13: Compound decisions — included in W13/
- W14: Prove a Boolean equivalence — included in W14/
- W15: Negation repair shop — included in W15/