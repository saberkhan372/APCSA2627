# Unit 4 assessment

Friday, March 12, 2027, 10:15-11:30

## In class
Complete 18 MC questions (39 min), one new ArrayList or 2D method (26 min), and a reflection (10 min). Earlier checkpoints provide evidence for the other structure.

## Turn in
Independent assessment with all Unit 4 strands represented across the assessment cycle.

## After class
20 min: complete two corrections with counterexamples.

Due: 2027-03-16
