# Materials

- W46: Weather Data Analyzer — included in W46/
- W48: Cross the wrapper boundary — included in W48/
- L22: Chapter 7.5 B: Weather Data Analyzer — provided by your teacher in Classroom; not included in this public packet
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf