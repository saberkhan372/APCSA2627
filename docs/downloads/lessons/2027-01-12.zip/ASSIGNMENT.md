# Weather Data Analyzer and parsing

Tuesday, January 12, 2027, 10:15-11:30

## In class
Use the corrected W46 project. Process each weekly line; split values and parse numeric Strings. Compute each weekly mean and overall maximum.

## Turn in
WeatherData checks; per-week results; a token/line trace and parsing explanation.

## After class
20 min: finish the three-week fixture and a one-week test.

Due: 2027-01-14
