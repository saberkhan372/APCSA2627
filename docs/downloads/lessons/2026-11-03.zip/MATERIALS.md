# Materials

- F24: 2024 released FRQs — https://apcentral.collegeboard.org/media/pdf/ap24-frq-comp-sci-a.pdf
- W18: Build and test String algorithms — included in W18/
- W20: Count executions, not milliseconds — included in W20/