# Selection and iteration synthesis

Tuesday, November 3, 2026, 10:15-11:30

## In class
Finish the Feeder runner; choose the weakest of loop bounds, String scans or Boolean equivalence for focused repair. Explain a method without executing it.

## Turn in
Working runner; six mixed retrieval answers; one oral explanation.

## After class
25 min: revise the Unit 2 error log and rehearse two method skeletons.

Due: 2026-11-05
