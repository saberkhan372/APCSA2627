# Materials

- W30: Share state with static — included in W30/
- W31: Audit static method access — included in W31/
- L15: Counting Transactions — provided by your teacher in Classroom; not included in this public packet