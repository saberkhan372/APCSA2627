# Ticket static state

Tuesday, November 17, 2026, 08:50-10:05

## In class
Complete Ticket and observe what all objects share. Link the model to Counting Transactions; decide which members belong to the class and which belong to each object.

## Turn in
Ticket checks; two-object trace; static-versus-instance explanation.

## After class
20 min: complete W31 static-access questions and repair one illegal call.

Due: 2026-11-19
