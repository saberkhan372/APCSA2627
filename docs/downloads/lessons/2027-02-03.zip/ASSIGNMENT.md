# 2026 FRQ 3: Attendance

Wednesday, February 3, 2027, 13:00-14:15

## In class
Attempt the one-method Attendance problem for 23 minutes. Trace matches across both lists and verify that neither list changes, then revise and test.

## Turn in
Timed method; corrected method; cases for matching and nonmatching IDs.

## After class
20 min: explain nested-list traversal and one missed case.

Due: 2027-02-05
