# Class design transfer and repair

Wednesday, December 2, 2026, 10:55-12:10

## In class
Finish StepTracker, swap test cases, and do eight Unit 3 MC questions. Explain a complete constructor and a state-changing method without the IDE.

## Turn in
Final StepTracker; eight responses; revised class-design checklist.

## After class
20 min: rehearse a fresh class specification; no additional project.

Due: 2026-12-04
