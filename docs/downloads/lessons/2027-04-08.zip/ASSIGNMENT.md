# FRQ 1: Account

Thursday, April 8, 2027, 10:15-11:30

## In class
Attempt 2026 Q1 Account in 28 minutes, covering both constructor and String method. Use remaining time to compare to the contract, correct and test.

## Turn in
Timed Q1; two corrected parts; explain unchanged username postcondition.

## After class
20 min: rewrite the weakest part from a blank editor.

Due: 2027-04-12
