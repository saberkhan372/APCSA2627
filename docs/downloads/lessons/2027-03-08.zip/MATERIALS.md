# Materials

- APC: AP Classroom question bank — https://apclassroom.collegeboard.org/
- W56: Build row and column algorithms — included in W56/
- W63: Trace sorting invariants — included in W63/
- W64: Trace recursion without writing it — included in W64/