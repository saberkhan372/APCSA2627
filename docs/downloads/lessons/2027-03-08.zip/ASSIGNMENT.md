# 2D/search/sort/recursion checkpoint

Monday, March 8, 2027, 14:25-15:40

## In class
Complete 12 analysis questions (26 min), a short 2D method (24 min), then correct the two weakest categories (25 min).

## Turn in
Independent checkpoint; repaired 2D method and one trace.

## After class
15 min: finish two corrections.

Due: 2027-03-10
