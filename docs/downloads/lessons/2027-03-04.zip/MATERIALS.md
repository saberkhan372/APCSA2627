# Materials

- W65: Trace recursive search and merge sort — included in W65/
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf