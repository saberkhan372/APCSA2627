# Recursive binary search and merge sort

Thursday, March 4, 2027, 08:50-10:05

## In class
Trace a recursive String/collection walk, binary search calls, and merge-sort split/merge stages. Explain the sorted halves before each merge.

## Turn in
RecursiveAlgorithms checks; call trace; complete merge tree for eight values.

## After class
20 min: one fresh recursive trace and one merge-stage explanation.

Due: 2027-03-08
