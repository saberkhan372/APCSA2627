# StepTracker class lab

Monday, November 30, 2026, 13:00-14:15

## In class
Re-entry trace, then write StepTracker from its interaction table. Test no recorded days, below threshold, exactly threshold and repeated updates.

## Turn in
StepTracker.java plus table-driven tests; explain averageSteps numeric type.

## After class
20 min: finish tests and annotate field choices.

Due: 2026-12-02
