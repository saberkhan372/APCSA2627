# Changing People and reference ownership

Friday, November 13, 2026, 10:15-11:30

## In class
Trace mutation versus reassignment in Changing People, then complete the corresponding reference-ownership project. Explain passing a reference by value.

## Turn in
Before/after object diagrams; reference-ownership checks; a method contract.

## After class
20 min: trace two aliases to one object and one reassigned parameter.

Due: 2026-11-17
