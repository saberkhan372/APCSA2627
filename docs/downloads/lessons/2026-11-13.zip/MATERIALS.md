# Materials

- L14: Changing People: parameter passing — provided by your teacher in Classroom; not included in this public packet
- W29: Pass references with intent — included in W29/