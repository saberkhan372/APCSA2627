# Recursion call-stack tracing

Tuesday, March 2, 2027, 10:15-11:30

## In class
Predict supplied methods before running RecursionTrace. Track separate local variables, base cases and output before/after each call.

## Turn in
Call-stack diagrams and predicted output; RecursionTrace checks.

## After class
20 min: four teacher-selected output traces from the recursion packet.

Due: 2027-03-04
