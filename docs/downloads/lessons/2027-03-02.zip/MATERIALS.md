# Materials

- W64: Trace recursion without writing it — included in W64/
- L23: Recursion Practice In Class — provided by your teacher in Classroom; not included in this public packet
- L24: Recursion Practice homework — provided by your teacher in Classroom; not included in this public packet