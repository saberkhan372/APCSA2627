# Chapter 1 launch and Eclipse setup

Friday, September 4, 2026, 08:50-10:05

## In class
Review the Chapter 1 work already assigned: Eclipse setup, Part A/B videos, prequizzes and Lab Exercise 5.

## Turn in
Existing Chapter 1 work; no new retrospective submission.

## After class
As already assigned: Chapter 1 Part A/B prequizzes and Lab Exercise 5 for Sep 9.

Due: 2026-09-09
