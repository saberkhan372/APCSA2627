# Materials

- L01: Chapter 1 Lab Exercise 5: compiler errors — provided by your teacher in Classroom; not included in this public packet