# Materials

- F24: 2024 released FRQs — https://apcentral.collegeboard.org/media/pdf/ap24-frq-comp-sci-a.pdf
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf