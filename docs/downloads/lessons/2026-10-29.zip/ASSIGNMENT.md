# Methods checkpoint: Feeder

Thursday, October 29, 2026, 13:00-14:15

## In class
Attempt 2024 Q1 Feeder part (a) independently for 20 minutes. Compare to the specification; discuss repeated calls in part (b), then revise.

## Turn in
Timed method, annotated correction and normal/boundary tests.

## After class
20 min: implement the corrected method in a small runner with fixed test inputs.

Due: 2026-11-03
