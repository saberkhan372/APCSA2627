# Materials

- L09: Powers of 2 — provided by your teacher in Classroom; not included in this public packet
- H04: Loop Programs — provided by your teacher in Classroom; not included in this public packet
- L10: Finding Maximum and Minimum Values — provided by your teacher in Classroom; not included in this public packet