# Powers of 2 and accumulation

Tuesday, October 20, 2026, 10:15-11:30

## In class
Write Powers of 2 without Math.pow. Complete Loop Programs #1 items 1, 2 and 4. Compare a running sum with repeated multiplication.

## Turn in
Four short programs; loop bounds and accumulator explanation.

## After class
20 min: L10 temperature extrema with all-negative and tied values; finish in class next time if needed.

Due: 2026-10-23
