# Materials

- W44: Read tokens with File and Scanner — included in W44/
- L21: Chapter 7.5 A: Inventory Auditor — provided by your teacher in Classroom; not included in this public packet
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf