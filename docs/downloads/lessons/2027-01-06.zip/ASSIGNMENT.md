# TokenReader: text-file input

Wednesday, January 6, 2027, 14:25-15:40

## In class
Re-entry array trace. Open a File with Scanner, read tokens with hasNext/nextInt, and explain imports, file location, close and the required exception declaration.

## Turn in
TokenReader checks; annotated read loop; source file packaged with code.

## After class
20 min: trace Inventory Auditor on the seven values in L21; predict sum/minimum.

Due: 2027-01-08
