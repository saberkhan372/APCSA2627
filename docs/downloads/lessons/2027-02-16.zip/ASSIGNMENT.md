# Magic Squares lab, part 2

Tuesday, February 16, 2027, 13:00-14:15

## In class
Finish tests and demonstrate the checker. Explain why changing cells while scanning can invalidate a decision; trace a separate read/write grid example.

## Turn in
Final checker, four tests and one original debugging explanation.

## After class
20 min: rewrite one row/column method without compiler feedback.

Due: 2027-02-18
