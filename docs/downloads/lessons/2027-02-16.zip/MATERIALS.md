# Materials

- L19: Magic Squares — provided by your teacher in Classroom; not included in this public packet
- W56: Build row and column algorithms — included in W56/