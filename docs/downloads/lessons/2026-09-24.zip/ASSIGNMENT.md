# String Output Lineup and StringRelations

Thursday, September 24, 2026, 13:00-14:15

## In class
Predict the Lineup outputs. Repair sameText and order; compare ==, equals and compareTo using distinct String objects. Keep split/parsing for Unit 4.

## Turn in
StringRelations checks; corrected Lineup answers; explain immutability.

## After class
20 min: retry three missed String outputs and finish method cards.

Due: 2026-09-28
