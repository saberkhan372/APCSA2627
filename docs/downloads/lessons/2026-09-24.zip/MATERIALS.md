# Materials

- H02: String Output Lineup — provided by your teacher in Classroom; not included in this public packet
- W08: Compare String contents — included in W08/
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf