# Weather investigation: authentic data

Thursday, January 14, 2027, 08:50-10:05

## In class
Apply the same pipeline to the selected public weather sample. Calculate an aggregate, identify a limitation and verify one result by hand.

## Turn in
Source-cited data brief, program, two checks and a supported conclusion.

## After class
20 min: finish the brief and note one missing-value assumption.

Due: 2027-01-20
