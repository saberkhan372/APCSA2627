# Arrays and files checkpoint

Friday, January 22, 2027, 13:00-14:15

## In class
Complete ten MC questions (22 min) and a file-to-array method task (25 min), then explain and repair errors (28 min).

## Turn in
Independent checkpoint; corrected file loop and wrapper/list trace.

## After class
15 min: finish corrections.

Due: 2027-01-26
