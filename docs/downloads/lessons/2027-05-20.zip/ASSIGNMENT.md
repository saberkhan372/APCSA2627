# Final project: first working version

Thursday, May 20, 2027, 13:00-14:15

## In class
Implement one complete input-to-output path. Test it with a tiny fixture and explain a design decision in a code conference.

## Turn in
Runnable first version and one passing acceptance test.

## After class
25 min: finish the core feature and record the next bug.

Due: 2027-05-24
