# Using objects and tracing aliases

Thursday, September 17, 2026, 08:50-10:05

## In class
Use the provided complete Player class in AliasingLab. Create two objects, call instance methods and diagram reassignment, aliasing and null. Discuss signatures without requiring class design yet.

## Turn in
Four-stage reference diagram; AliasingLab checks; distinguish class and instance calls.

## After class
20 min: trace the first three-object diagram in L13; do not type the full legacy project.

Due: 2026-09-22
