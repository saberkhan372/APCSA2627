# Targeted review and recovery

Thursday, April 22, 2027, 08:50-10:05

## In class
Use the error log: eight fresh MC items plus one weak method/trace. Recover Apr 16 practice or unfinished core content before adding extra questions.

## Turn in
Eight justified answers; one corrected independent method or trace.

## After class
20 min: rehearse JQR lookup and the next mock-section pacing.

Due: 2027-04-26
