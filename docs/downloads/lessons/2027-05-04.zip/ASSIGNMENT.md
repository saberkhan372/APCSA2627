# FRQ simulation: second pair

Tuesday, May 4, 2027, 08:50-10:05

## In class
Use a fresh current-format ArrayList and 2D pair for 40 minutes, then review both simulations for 35 minutes.

## Turn in
Two independent FRQs; combined four-question skill review.

## After class
15 min: revise the personal reference/error checklist.

Due: 2027-05-06
