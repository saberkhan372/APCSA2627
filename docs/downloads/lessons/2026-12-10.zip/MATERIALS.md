# Materials

- W38: Create and index arrays safely — included in W38/
- L16: Tracking Sales: Basic Arrays — provided by your teacher in Classroom; not included in this public packet