# ArrayAccess and Tracking Sales

Thursday, December 10, 2026, 13:00-14:15

## In class
Create primitive and object arrays; distinguish length from valid indexes and default values. Complete ArrayAccess and begin a single-pass sales traversal.

## Turn in
ArrayAccess checks; reference/default-value diagram; predicted totals.

## After class
20 min: finish the sales total/average with supplied fictional data.

Due: 2026-12-14
