# GridTraversal and row/column sums

Tuesday, February 9, 2027, 08:50-10:05

## In class
Traverse a nonsquare grid in both orders, then implement row sums, column sums and a search with early return. Explain every loop bound.

## Turn in
GridTraversal/GridAlgorithms checks for selected methods; 2-by-3 test grid.

## After class
20 min: hand-compute row, column and diagonal totals for a 3-by-3 square.

Due: 2027-02-11
