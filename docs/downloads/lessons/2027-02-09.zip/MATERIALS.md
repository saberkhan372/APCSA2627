# Materials

- W55: Trace row-major traversal — included in W55/
- W56: Build row and column algorithms — included in W56/
- L19: Magic Squares — provided by your teacher in Classroom; not included in this public packet