# MC simulation: first half

Monday, April 26, 2027, 14:25-15:40

## In class
Do 21 previously unseen current-framework questions in 45 minutes. Use 30 minutes for corrections and distractor explanations.

## Turn in
Timed half-section responses; error categories and time per question.

## After class
20 min: finish the correction log; no new full packet.

Due: 2027-04-28
