# GridBridge: coordinates to 2D arrays

Friday, February 5, 2027, 10:15-11:30

## In class
Map Processing x/y to row/column, create a rectangular grid and trace dimensions. Use a 2-by-3 array to expose swapped bounds.

## Turn in
GridBridge checks; labeled row/column diagram; correct dimension expressions.

## After class
20 min: predict two row-major and two column-major traversals.

Due: 2027-02-09
