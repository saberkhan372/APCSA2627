# Portfolio handoff and course close

Wednesday, June 2, 2027, 13:00-14:15

## In class
Submit the final project and choose three artifacts showing growth in code analysis, class design and data processing. Reflect on one repaired misconception.

## Turn in
Private portfolio/project ZIP, reflection and final test evidence.

## After class
None; follow school instructions if an additional final-exam meeting is required.
