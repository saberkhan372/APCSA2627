# Chapter 1 quiz and Lab Exercise 5

Wednesday, September 9, 2026, 14:25-15:40

## In class
Check the Hello.java error experiments, then take the already-posted nine-question quiz. Debrief syntax versus output errors and preview integer division.

## Turn in
Existing Lab 5 file/answers; nine-question quiz; one corrected error explanation.

## After class
20 min: preview L02 Two Meanings of Plus; predict each output before compiling.

Due: 2026-09-11
