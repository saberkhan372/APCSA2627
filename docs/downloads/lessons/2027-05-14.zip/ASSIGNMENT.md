# Final project: choose and scope

Friday, May 14, 2027, 08:50-10:05

## In class
Reflect on preparation, then choose a weather-data tool, Shopping Cart extension or grid simulation. Define a user, a question and a smallest working version.

## Turn in
Half-page proposal with three success criteria.

## After class
20 min: refine the proposal and a sketch of the interface/model.

Due: 2027-05-18
