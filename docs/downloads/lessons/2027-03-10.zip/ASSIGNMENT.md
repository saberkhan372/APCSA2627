# Weather investigation: collections extension

Wednesday, March 10, 2027, 13:00-14:15

## In class
Finish authentic-data transfer if pending. Choose array, ArrayList or 2D array for a justified analysis; implement one aggregate and one filter/group comparison.

## Turn in
Source-cited investigation, justified structure choice and two manual checks.

## After class
20 min: finalize the investigation and a five-sentence limitation statement.

Due: 2027-03-12
