# Materials

- W46: Weather Data Analyzer — included in W46/
- W50: Traverse a changing-size collection — included in W50/
- W56: Build row and column algorithms — included in W56/
- W37: Match data to a question — included in W37/