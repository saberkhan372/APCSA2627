# Materials

- W50: Traverse a changing-size collection — included in W50/
- W51: Remove without skipping — included in W51/