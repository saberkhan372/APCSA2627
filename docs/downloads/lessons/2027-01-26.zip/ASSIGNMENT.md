# ListTraversal and safe removal

Tuesday, January 26, 2027, 10:15-11:30

## In class
Complete ListTraversal, then use ListRemoval to expose skipped adjacent matches. Trace forward, adjusted-forward and backward passes before coding.

## Turn in
List traversal/removal checks; before/after index table.

## After class
20 min: test adjacent removals, all removed and none removed.

Due: 2027-01-28
