# Materials

- L07: Activities at Lake LazyDays — provided by your teacher in Classroom; not included in this public packet
- L08: Date Validation — provided by your teacher in Classroom; not included in this public packet
- W12: Selection speed-run — included in W12/