# Activities at Lake LazyDays

Friday, October 2, 2026, 14:25-15:40

## In class
Translate temperature rules into a cascading if/else. Test 39/40, 59/60 and 79/80 before running; explain equality and branch order.

## Turn in
Working activities program and six-case boundary table.

## After class
20 min: Date Validation month/year conditions and expected outcomes, before coding.

Due: 2026-10-06
