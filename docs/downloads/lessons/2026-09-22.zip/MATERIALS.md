# Materials

- H01: String Activity — provided by your teacher in Classroom; not included in this public packet
- W07: Index a String safely — included in W07/
- L05: Working with Strings — provided by your teacher in Classroom; not included in this public packet
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf