# String Activity and WordTools

Tuesday, September 22, 2026, 14:25-15:40

## In class
Complete String Activity with short teacher-supplied strings. Draw indexes; implement firstWord and safeSlice from supplied headers, then check boundary behavior.

## Turn in
WordTools checks; index diagram; predicted length/substring/indexOf results.

## After class
20 min: L05 Working with Strings prediction/verification table; six JQR method cards.

Due: 2026-09-24
