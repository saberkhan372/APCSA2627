# Binary search

Wednesday, February 24, 2027, 14:25-15:40

## In class
Trace iterative binary search and its sorted-input precondition. Compare comparisons with linear search; test missing and boundary targets.

## Turn in
Low/high/mid trace table; sorted-input counterexample; selected SearchLab checks.

## After class
20 min: predict two selection-sort passes on five values.

Due: 2027-02-26
