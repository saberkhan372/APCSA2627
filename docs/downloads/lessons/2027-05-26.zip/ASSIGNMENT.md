# Final project: test and document

Wednesday, May 26, 2027, 09:30-10:45

## In class
Resolve bugs, test from a clean launch and write README instructions, data attribution and limitations. Rehearse a five-minute demo.

## Turn in
Candidate final ZIP/project folder, README and test evidence.

## After class
20 min: finish demo preparation and documentation.

Due: 2027-05-28
