# Materials

- W46: Weather Data Analyzer — included in W46/
- L18: Shopping Cart using an ArrayList — provided by your teacher in Classroom; not included in this public packet
- W56: Build row and column algorithms — included in W56/