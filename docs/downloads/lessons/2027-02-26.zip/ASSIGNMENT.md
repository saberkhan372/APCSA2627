# Selection and insertion sort

Friday, February 26, 2027, 13:00-14:15

## In class
Use SortTrace to track selection-sort passes and insertion-sort shifts. State what prefix is settled/sorted and compare already-sorted/reversed inputs.

## Turn in
SortTrace checks; one pass table for each algorithm; invariant explanation.

## After class
20 min: complete one fresh trace of each sort; record comparisons versus swaps/shifts.

Due: 2027-03-02
