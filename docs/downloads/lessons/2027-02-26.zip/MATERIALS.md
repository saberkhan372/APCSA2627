# Materials

- W63: Trace sorting invariants — included in W63/
- L25: Searching and Sorting in an Integer List — provided by your teacher in Classroom; not included in this public packet