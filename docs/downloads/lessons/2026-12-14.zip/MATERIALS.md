# Materials

- W39: Traverse exactly once — included in W39/
- W40: Know the enhanced-for limit — included in W40/
- L17: Reversing an Array — provided by your teacher in Classroom; not included in this public packet