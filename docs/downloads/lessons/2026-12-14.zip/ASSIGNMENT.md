# ArrayTraversal and enhanced-for limits

Monday, December 14, 2026, 10:15-11:30

## In class
Build count/sum/min/max passes. Show why assigning an enhanced-for loop variable does not replace an array element; contrast object mutation.

## Turn in
Traversal checks; corrected enhanced-for examples; bounds explanation.

## After class
20 min: trace reversal on even- and odd-length arrays; write swaps before coding.

Due: 2026-12-16
