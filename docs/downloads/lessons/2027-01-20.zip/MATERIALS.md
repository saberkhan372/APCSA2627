# Materials

- W48: Cross the wrapper boundary — included in W48/
- W49: Use the five ArrayList methods — included in W49/
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf