# WrapperLab and ArrayList methods

Wednesday, January 20, 2027, 14:25-15:40

## In class
Contrast int with Integer, parse methods, boxing/unboxing and null. Complete ListMethods with typed ArrayList<Integer> and ArrayList<String>.

## Turn in
Wrapper/list method checks; table of add/get/set/remove/size effects and return values.

## After class
20 min: make method cards and predict a six-operation list trace.

Due: 2027-01-22
