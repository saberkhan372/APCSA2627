# String scan and removal algorithms

Friday, October 23, 2026, 08:50-10:05

## In class
Finish a short extrema check. Implement removeCharacter and countDouble; count non-overlapping pairs, including the aaaa case. Trace an empty and one-character String.

## Turn in
StringAlgorithms checks; one original edge case; precise loop invariant.

## After class
20 min: complete countLetter/removeLetter in W09 as transfer, using the supplied headers.

Due: 2026-10-27
