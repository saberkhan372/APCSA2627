# Materials

- W18: Build and test String algorithms — included in W18/
- W17: Scan a String safely — included in W17/
- W09: Build a one-pass String algorithm — included in W09/
- L10: Finding Maximum and Minimum Values — provided by your teacher in Classroom; not included in this public packet