# FRQ 3: WordChecker transfer

Wednesday, April 14, 2027, 14:25-15:40

## In class
Attempt 2024 Q3 parts (a)/(b) as a selected skill set (30 min), then identify list iteration, adjacent-element and String assumptions and revise.

## Turn in
Timed list/String methods; corrected tests for adjacent entries.

## After class
20 min: redo one list algorithm independently.

Due: 2027-04-16
