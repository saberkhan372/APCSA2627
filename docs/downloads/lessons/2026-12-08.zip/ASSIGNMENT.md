# Data decision and weather investigation

Tuesday, December 8, 2026, 14:25-15:40

## In class
Compare two non-personal datasets. Identify a question, source, units, missing-data risk and collection bias. Run DataConsent/DatasetFit examples and write a data-use note.

## Turn in
One-page dataset brief; one defensible and one unsupported claim; checks for selected starter tasks.

## After class
20 min: inspect a small teacher-provided public weather sample and label fields/units.

Due: 2026-12-10
