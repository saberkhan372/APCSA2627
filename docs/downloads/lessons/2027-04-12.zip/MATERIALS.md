# Materials

- F25: 2025 released FRQs — https://apcentral.collegeboard.org/media/pdf/ap25-frq-computer-science-a.pdf
- L12: StepTracker: 2019 FRQ 2 — provided by your teacher in Classroom; not included in this public packet
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf