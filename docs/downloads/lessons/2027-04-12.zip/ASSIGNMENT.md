# FRQ 2: fresh class design

Monday, April 12, 2027, 08:50-10:05

## In class
Attempt 2025 Q2 as a fresh class task (25 min). Compare the representation and method logic to Bottle and StepTracker; correct and explain.

## Turn in
Timed class; field/state diagram; corrected method.

## After class
20 min: one constructor/state-change trace and a short class checklist.

Due: 2027-04-14
