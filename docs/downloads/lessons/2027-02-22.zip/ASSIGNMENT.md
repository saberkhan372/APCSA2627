# Linear search and search contracts

Monday, February 22, 2027, 08:50-10:05

## In class
Implement/trace sequential search over integers and Strings. Test first, last, missing and duplicated targets; explain the returned index contract.

## Turn in
SearchLab checks for linear cases; comparison-count table.

## After class
20 min: trace searches in a sorted seven-element array and record low/high/mid.

Due: 2027-02-24
