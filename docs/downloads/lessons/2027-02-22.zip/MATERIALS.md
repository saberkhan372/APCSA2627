# Materials

- W62: Choose sequential or binary search — included in W62/
- H08: Sequential and Binary Search Lab — provided by your teacher in Classroom; not included in this public packet