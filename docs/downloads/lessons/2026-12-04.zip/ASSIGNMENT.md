# Unit 3 assessment: Bottle

Friday, December 4, 2026, 08:50-10:05

## In class
Write 2026 Q2 Bottle independently (35 min), answer eight selected Unit 3 MC items (17 min), then inspect examples and start corrections (23 min).

## Turn in
Complete independent class, MC responses and correction notes.

## After class
15 min: finish corrections.

Due: 2026-12-08
