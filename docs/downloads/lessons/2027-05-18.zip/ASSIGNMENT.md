# Final project: design and tests

Tuesday, May 18, 2027, 14:25-15:40

## In class
Specify classes, data structure, input/output and three acceptance tests. Build a skeleton and agree on two implementation milestones.

## Turn in
Design diagram, acceptance tests and runnable skeleton.

## After class
20 min: implement the smallest core method.

Due: 2027-05-20
