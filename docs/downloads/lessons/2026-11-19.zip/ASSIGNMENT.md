# HotelRoom: scope and this

Thursday, November 19, 2026, 14:25-15:40

## In class
Complete HotelRoom; repair shadowed fields with this, reason about private/public access, and explain a precondition at a code conference.

## Turn in
HotelRoom checks; scope map; correct constructor assignments.

## After class
None over Thanksgiving. Keep your class-design checklist for Nov 30.
