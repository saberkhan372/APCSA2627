# Materials

- W32: Resolve scope with this — included in W32/