# Materials

- W45: Inventory Auditor — included in W45/
- L21: Chapter 7.5 A: Inventory Auditor — provided by your teacher in Classroom; not included in this public packet
- L22: Chapter 7.5 B: Weather Data Analyzer — provided by your teacher in Classroom; not included in this public packet