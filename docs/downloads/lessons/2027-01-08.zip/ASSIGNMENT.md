# Inventory Auditor

Friday, January 8, 2027, 13:00-14:15

## In class
Complete InventoryAudit using the supplied synthetic data. Compare token reading with line reading; test whitespace variation and document empty-file behavior.

## Turn in
InventoryAudit checks; sum/minimum result; empty-file rule and working-directory note.

## After class
20 min: preview Weather Data Analyzer and mark where each weekly line begins/ends.

Due: 2027-01-12
