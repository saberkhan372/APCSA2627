# Unit 1 assessment

Wednesday, September 30, 2026, 09:30-10:45

## In class
Complete 12 current-topic MC questions (26 min), two short supplied-header code tasks (24 min), then explain and begin corrections (25 min).

## Turn in
Independent assessment and first corrections; no compiler during assessment.

## After class
15 min: finish corrections and make a boundary-test checklist.

Due: 2026-10-02
