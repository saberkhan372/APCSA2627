# Final project: feature completion

Monday, May 24, 2027, 10:10-11:20

## In class
Complete required features and run peer-created boundary tests. Prioritize correctness over adding features.

## Turn in
All required features working; bug list with reproduction steps.

## After class
20 min: repair the highest-priority bug.

Due: 2027-05-26
