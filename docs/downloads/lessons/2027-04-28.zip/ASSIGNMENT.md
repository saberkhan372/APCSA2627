# MC simulation: second half

Wednesday, April 28, 2027, 13:00-14:15

## In class
Do the second 21 unseen questions in 45 minutes, then correct. Combine the halves as a skill baseline, not a stamina-tested full section.

## Turn in
Second half-section responses; combined 42-question analysis.

## After class
20 min: correct the two most persistent errors.

Due: 2027-04-30
