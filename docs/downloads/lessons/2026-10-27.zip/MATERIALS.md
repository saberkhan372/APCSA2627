# Materials

- W19: Nested iteration — included in W19/
- W20: Count executions, not milliseconds — included in W20/