# PatternLab and operation counts

Tuesday, October 27, 2026, 14:25-15:40

## In class
Implement the staircase; trace factor-pair loops. Count body executions for n=3 and n=5 and compare constant, linear and quadratic growth.

## Turn in
PatternLab checks; two operation-count tables and a growth explanation.

## After class
20 min: finish W20 runtime counts and one wrong-bound correction.

Due: 2026-10-29
