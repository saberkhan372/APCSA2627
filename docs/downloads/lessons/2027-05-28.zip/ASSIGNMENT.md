# Final project demonstrations

Friday, May 28, 2027, 14:25-15:40

## In class
Each student demonstrates the project, explains a core method and handles one new test case. Use remaining time for revisions.

## Turn in
Project demo, explanation and final revision list.

## After class
15 min: final edits and a short learning reflection.

Due: 2027-06-02
