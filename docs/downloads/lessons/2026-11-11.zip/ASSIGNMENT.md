# BandBooster methods and tests

Wednesday, November 11, 2026, 13:00-14:15

## In class
Finish updateSales and a small runner with three fictional boosters. Test state before and after repeated updates; distinguish a returned value from printed output.

## Turn in
Working BandBooster class/runner; at least four predicted/actual tests.

## After class
20 min: write a second constructor proposal with explicit defaults; explain valid initialization.

Due: 2026-11-13
