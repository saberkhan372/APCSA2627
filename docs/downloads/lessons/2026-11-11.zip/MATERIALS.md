# Materials

- L11: Band Booster Class — provided by your teacher in Classroom; not included in this public packet
- W25: Construct a valid object — included in W25/
- W26: Overload without duplicating rules — included in W26/
- W27: Return information, not output — included in W27/