# Materials

- W03: Control a random range — included in W03/
- L06: Rolling Dice — provided by your teacher in Classroom; not included in this public packet
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf