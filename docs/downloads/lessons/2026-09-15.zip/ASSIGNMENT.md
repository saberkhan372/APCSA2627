# DiceLab and Rolling Dice

Tuesday, September 15, 2026, 10:15-11:30

## In class
Read the API and method contracts. Complete scaleSample and roll; test samples 0 and just below 1, then simulate six- and eight-sided dice.

## Turn in
DiceLab checks; interval argument; documented parameter/return types.

## After class
20 min: finish L06 Rolling Dice; label the four outputs and total.

Due: 2026-09-17
