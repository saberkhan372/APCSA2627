# 2026 FRQ 4: GameBoard

Thursday, February 18, 2027, 10:15-11:30

## In class
Attempt getPointsForRow for 23 minutes. Trace sums and same-color comparison, then test all-same and mixed-color rows and revise.

## Turn in
Timed method, correction and two concrete test rows.

## After class
20 min: describe a linear search and its result when a target is absent.

Due: 2027-02-22
