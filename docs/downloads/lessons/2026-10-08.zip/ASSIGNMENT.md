# LoopTrace and termination

Thursday, October 8, 2026, 10:15-11:30

## In class
Trace initialization, test, body and update. Complete sumTo and countBy in LoopTrace; compare zero/one/many iterations. Record the final trace row for countBy(1, 8, 2).

## Turn in
LoopTrace checks; trace table; a termination explanation.

## After class
Up to 20 min by Oct 20: finish the loop trace repair before or after the school trip week. No required work during Oct 12-16.

Due: 2026-10-20
