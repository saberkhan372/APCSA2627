# Materials

- W16: Trace the loop before writing it — included in W16/