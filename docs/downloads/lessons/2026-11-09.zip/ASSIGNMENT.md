# Duck design and BandBooster launch

Monday, November 9, 2026, 14:25-15:40

## In class
Turn the Duck diagram into private fields and a public interface. Design BandBooster; discuss which information the model needs and how design can exclude users.

## Turn in
Class diagram; BandBooster field/constructor skeleton; one design-impact paragraph.

## After class
20 min: implement BandBooster constructor and getName.

Due: 2026-11-11
