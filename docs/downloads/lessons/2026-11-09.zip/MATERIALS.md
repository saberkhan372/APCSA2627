# Materials

- H05: Duck class diagram — provided by your teacher in Classroom; not included in this public packet
- L11: Band Booster Class — provided by your teacher in Classroom; not included in this public packet
- W23: Design the class boundary — included in W23/