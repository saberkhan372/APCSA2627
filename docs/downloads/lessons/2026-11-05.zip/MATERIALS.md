# Materials

- APC: AP Classroom question bank — https://apclassroom.collegeboard.org/
- H05: Duck class diagram — provided by your teacher in Classroom; not included in this public packet