# Unit 2 assessment

Thursday, November 5, 2026, 08:50-10:05

## In class
Complete 12 MC questions (26 min), two short methods covering loops and Strings (34 min), and an explanation/correction (15 min).

## Turn in
Independent assessment; one corrected loop invariant.

## After class
15 min: complete corrections and sketch fields/behaviors for a Duck.

Due: 2026-11-09
