# Unit 1 retrieval and repair

Monday, September 28, 2026, 10:15-11:30

## In class
Predict the six Unit1Review results before running. Repair the two weakest categories, then complete eight teacher-selected AP Classroom Unit 1 questions.

## Turn in
Review checks; eight MC responses; personal two-item error log.

## After class
25 min: rehearse casts, method calls and String indexes; rewrite two corrected examples.

Due: 2026-09-30
