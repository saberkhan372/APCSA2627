# Bluebook rehearsal and final repair

Thursday, May 6, 2027, 14:25-15:40

## In class
Open the official preview, locate the JQR and practice entering/indenting Java. Complete one short plain-editor method and one targeted trace without compiler feedback.

## Turn in
Preview/navigation completed; typed method; final two-error repair.

## After class
15 min: confirm coordinator instructions, device readiness and permitted materials.

Due: 2027-05-10
