# Materials

- L18: Shopping Cart using an ArrayList — provided by your teacher in Classroom; not included in this public packet
- W51: Remove without skipping — included in W51/