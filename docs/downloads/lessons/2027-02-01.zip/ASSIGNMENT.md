# Shopping Cart: mutation and review

Monday, February 1, 2027, 14:25-15:40

## In class
Add a remove-matching-items method as a plan-authored extension. Test consecutive matches and an empty cart; explain mutation order and present the design.

## Turn in
Final cart files, three mutation tests and a short code conference.

## After class
20 min: write the removal algorithm from memory, then correct it.

Due: 2027-02-03
