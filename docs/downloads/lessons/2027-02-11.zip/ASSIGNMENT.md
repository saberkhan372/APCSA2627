# Magic Squares lab, part 1

Thursday, February 11, 2027, 14:25-15:40

## In class
Build row/column/diagonal sum helpers and compare them with the first-row total. Use the supplied magic-square context and a deliberately broken square.

## Turn in
Core checker; two expected-result grids; bounds explanation.

## After class
20 min: add one grid that has equal rows but unequal columns.

Due: 2027-02-16
