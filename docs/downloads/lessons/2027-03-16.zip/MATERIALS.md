# Materials

- W51: Remove without skipping — included in W51/
- W56: Build row and column algorithms — included in W56/
- W63: Trace sorting invariants — included in W63/
- W65: Trace recursive search and merge sort — included in W65/