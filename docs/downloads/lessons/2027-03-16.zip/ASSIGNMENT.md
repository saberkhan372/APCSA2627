# Unit 4 repair and consolidation

Tuesday, March 16, 2027, 08:50-10:05

## In class
Conference on the assessment. Repair the two weakest collection algorithms, explain data-file assumptions and retry a fresh search/sort/recursion trace.

## Turn in
Corrected code; two fresh successful traces; April priority list.

## After class
20 min: rehearse one ArrayList and one 2D pattern.

Due: 2027-03-18
