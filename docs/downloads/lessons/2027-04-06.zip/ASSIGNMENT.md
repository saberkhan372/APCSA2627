# Return from break and diagnostic repair

Tuesday, April 6, 2027, 13:00-14:15

## In class
Retrieve String/index/list patterns, correct the baseline and do one targeted method. This is the first recovery slot if core content needs one more lesson.

## Turn in
Updated error log; corrected method; two named review priorities.

## After class
20 min: trace a String scan and annotate a method specification.

Due: 2027-04-08
