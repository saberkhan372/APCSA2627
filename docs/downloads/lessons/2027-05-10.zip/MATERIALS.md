# Materials

- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf
- BB: Bluebook test preview — https://bluebook.collegeboard.org/