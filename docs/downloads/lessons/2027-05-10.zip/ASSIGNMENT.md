# Light retrieval and exam logistics

Monday, May 10, 2027, 13:00-14:15

## In class
Complete six familiar retrieval items, walk through a class/list/grid plan, and confirm when and where to report. End with time for questions.

## Turn in
Personal one-page checklist and confirmed reporting details.

## After class
No new work; follow coordinator directions for May 12.
