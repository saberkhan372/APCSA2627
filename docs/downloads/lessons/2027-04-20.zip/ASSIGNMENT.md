# Timed FRQ pair

Tuesday, April 20, 2027, 10:15-11:30

## In class
Write a fresh teacher-selected Methods/Control and ArrayList pair for 45 minutes; spend 30 minutes evaluating the specification and revising.

## Turn in
Two timed responses; one fully rewritten method.

## After class
20 min: correct one unfinished response and record a pacing adjustment.

Due: 2027-04-22
