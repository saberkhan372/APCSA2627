# Cumulative pre-break baseline

Thursday, March 18, 2027, 14:25-15:40

## In class
Complete 21 fresh MC items in 45 minutes. Spend 30 minutes classifying errors by topic and choosing two April priorities.

## Turn in
Baseline responses; correction plan; list of uncertain Java behaviors.

## After class
Optional, at most 40 min over spring break: redo four misses and one short method. No new content or required break packet.
