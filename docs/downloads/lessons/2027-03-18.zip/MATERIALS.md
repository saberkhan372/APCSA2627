# Materials

- APC: AP Classroom question bank — https://apclassroom.collegeboard.org/
- JQR: Current Java Quick Reference — https://apcentral.collegeboard.org/media/pdf/ap-computer-science-a-java-quick-reference.pdf